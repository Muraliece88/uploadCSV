package com.example.csv.service;

import com.example.csv.repo.ExerciseRepo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class ServiceCSVTest {
    @InjectMocks
    private  ServiceCSV serviceCSV;
    @Mock
    private ExerciseRepo repo;

    @Test
    void findAll()
    {

       assertNotNull(serviceCSV.getAllData());

    }
    @Test
    void findbyCode()
    {

        assertEquals(serviceCSV.getByCode(anyString()),null);

    }

}