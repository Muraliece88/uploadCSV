package com.example.csv.controller;

import com.example.csv.service.ServiceCSV;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(Controller.class)
@AutoConfigureMockMvc
class ControllerTest {
    @Autowired
    private MockMvc mvc;
    @MockBean
    private ServiceCSV serviceCSV;

    @Test
    void getallData() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/api/fetchAll"))
                .andExpect(status().isOk());
    }
}