package com.example.csv.exceptions;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@RestControllerAdvice(basePackages = "com.example.csv")
public class ExceptionHandlers {
    @ExceptionHandler(FileStoreException.class)
    public ResponseEntity<ErrorResponse> handleCustomException(FileStoreException ex, WebRequest request) {

        log.error(ex.getLocalizedMessage(), ex);
        List<String> errorDesc = new ArrayList<>();
        errorDesc.add(ex.getLocalizedMessage());

        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.name(), errorDesc,
                request.getDescription(false), new Date());

        return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleOtherException(Exception ex, WebRequest request) {

        log.error(ex.getLocalizedMessage(), ex);
        List<String> errorDesc = new ArrayList<>();
        errorDesc.add(ex.getLocalizedMessage());

        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.name(), errorDesc,
                request.getDescription(false), new Date());

        return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.NOT_FOUND);
    }
}
