package com.example.csv.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Getter
public class ErrorResponse {
    private int code;
    private String message;
    private List<String> details;
    private String path;
    private Date timestamp;
}
