package com.example.csv.service;

import com.example.csv.entity.Exercise;
import com.example.csv.exceptions.FileStoreException;
import com.example.csv.repo.ExerciseRepo;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class ServiceCSV {
    @Autowired
    private ExerciseRepo repo;

    /**
     * Method to upload data
     * @param file
     * @return
     */
    public String uploadData(MultipartFile file)
    {
        List<Exercise> data=new ArrayList<>();
      try(BufferedReader reader =new BufferedReader
              (new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8)))
      {
          CSVParser csvParser=new CSVParser(reader,CSVFormat.DEFAULT.
                  withFirstRecordAsHeader().withTrim());
         csvParser.getRecords().stream().forEach(record->{
             Exercise exercise=new Exercise();
             DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
             exercise.setCode((record.get("code")));
             exercise.setSource(record.get("source"));
             exercise.setCodeListCode(record.get("codeListCode"));
             exercise.setLongDescription(record.get("longDescription"));
             exercise.setDisplayValue(record.get("displayValue"));
             exercise.setFromDate(LocalDate.parse(record.get("fromDate")==null ||record.get("fromDate").trim().isEmpty()  ?LocalDate.now().format(dateTimeFormatter): record.get("fromDate"),dateTimeFormatter));
             exercise.setToDate(LocalDate.parse(record.get("toDate")==null||record.get("toDate").trim().isEmpty() ?LocalDate.now().format(dateTimeFormatter):record.get("toDate"),dateTimeFormatter));
             exercise.setSortingPriority(
                     Integer.parseInt(record.get("sortingPriority")==null||
                             record.get("sortingPriority").trim().isEmpty()?
                             "0":record.get("sortingPriority")));
             data.add(exercise);
         });


      } catch (IOException e) {
          throw new FileStoreException("Failed to save data");
      }
        repo.saveAll(data);
        return "Successfully saved the data";
    }

    /**
     * Method to get all data
     * @return
     */
    public  List<Exercise> getAllData()
    {
       return  repo.findAll();

    }

    /**
     * Method to get by code
     * @param code
     * @return
     */
    public  Exercise getByCode(String code)
    {
        return  repo.findBycode(code);

    }

    /**
     * Method to delete All
     * @return
     */
    public String deleteAll()
    {
         repo.deleteAll();
         return "All data deleted";
    }
}
