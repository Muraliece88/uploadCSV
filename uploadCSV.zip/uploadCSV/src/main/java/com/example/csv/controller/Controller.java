package com.example.csv.controller;


import com.example.csv.entity.Exercise;
import com.example.csv.exceptions.FileStoreException;
import com.example.csv.service.ServiceCSV;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

@RestController
@Slf4j
public class Controller {
    @Autowired
    private final ServiceCSV service;

    public Controller(ServiceCSV service) {
        this.service = service;
    }

    @PostMapping( value = "/api/upload")
    ResponseEntity<String> uploadData(@RequestParam("file")MultipartFile file)
    {
        if(file.isEmpty())
        {
           return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("CSV file is empty ");
        }
        try {
            service.uploadData(file);
            return ResponseEntity.status(HttpStatus.OK).body("File uploaded successfully");

        }
        catch (FileStoreException e)
        {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(e.getMessage());
        }

    }

    @GetMapping( value = "/api/fetchAll")
    ResponseEntity<List<Exercise>> getallData()
    {
        return ResponseEntity.status(HttpStatus.OK).body(service.getAllData());

    }

    @GetMapping( value = "/api/fetchByCode/{code}")
    ResponseEntity<?> getData(@PathVariable String code)
    {
      Exercise exercise=  service.getByCode(code);
        if(Optional.ofNullable(exercise).isPresent())
        {
            return ResponseEntity.status(HttpStatus.OK).body(exercise);
        }
        else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No data found for the requested code");
        }

    }
    @DeleteMapping( value = "/api/deleteAll")
    ResponseEntity<String> deleteAll()
    {
        return ResponseEntity.status(HttpStatus.OK).body(service.deleteAll());
    }


}
