package com.example.csv.exceptions;

public class FileStoreException extends RuntimeException{
    public FileStoreException(String message)
    {
        super(message);
    }
}
